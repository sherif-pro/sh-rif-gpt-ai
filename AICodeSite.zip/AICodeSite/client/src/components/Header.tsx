import { Sparkles } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between gap-4">
        <Link href="/" data-testid="link-home">
          <div className="flex items-center gap-2 hover-elevate rounded-lg px-3 py-2 cursor-pointer">
            <div className="relative">
              <Sparkles className="h-6 w-6 text-primary" />
              <div className="absolute inset-0 blur-md bg-primary/20"></div>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-tight">SHÉRIF GPT X1</span>
              <span className="text-xs text-muted-foreground">par Développeurs SHÉRIF</span>
            </div>
          </div>
        </Link>
        
        <div className="flex items-center gap-2">
          <Link href="/chat">
            <Button variant="default" size="default" data-testid="button-chat">
              Commencer le Chat
            </Button>
          </Link>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
