import { Sparkles } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export function TypingIndicator() {
  return (
    <div className="flex gap-4 items-start">
      <Avatar className="h-8 w-8 bg-primary">
        <AvatarFallback>
          <Sparkles className="h-4 w-4 text-white" />
        </AvatarFallback>
      </Avatar>
      
      <div className="flex items-center gap-1 bg-primary/10 rounded-2xl px-4 py-3" data-testid="typing-indicator">
        <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></div>
        <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></div>
        <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></div>
      </div>
    </div>
  );
}
