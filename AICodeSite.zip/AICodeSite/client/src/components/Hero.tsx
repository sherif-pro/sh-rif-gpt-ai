import { ArrowRight, Sparkles, Zap, Shield, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import heroImage from "@assets/generated_images/AI_neural_network_hero_8573f0fd.png";

export function Hero() {
  return (
    <div className="flex flex-col">
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImage} 
            alt="AI Technology" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-background"></div>
        </div>
        
        <div className="container relative z-10 py-16 md:py-24">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 bg-primary/20 backdrop-blur-sm border border-primary/30 rounded-full px-4 py-2 mb-4">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm text-white font-medium">Intelligence Artificielle de Nouvelle Génération</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-white">
              SHÉRIF GPT X1
            </h1>
            
            <p className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto">
              Assistant IA multimodal rapide et intelligent créé par les <span className="text-primary font-semibold">Développeurs SHÉRIF</span>
            </p>
            
            <div className="flex flex-wrap gap-4 justify-center pt-4">
              <Link href="/chat">
                <Button size="lg" className="gap-2 text-base" data-testid="button-start-chat">
                  Commencer le Chat
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="hover-elevate">
              <CardContent className="p-8">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Réponses Ultra-Rapides</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Obtenez des réponses instantanées grâce à notre technologie d'IA optimisée pour la vitesse.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-8">
                <div className="h-12 w-12 rounded-lg bg-chart-2/10 flex items-center justify-center mb-4">
                  <Upload className="h-6 w-6 text-chart-2" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Support Multimodal</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Analysez des images, documents PDF et autres fichiers avec notre IA avancée.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-8">
                <div className="h-12 w-12 rounded-lg bg-chart-3/10 flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-chart-3" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Créé par SHÉRIF</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Développé par les Développeurs SHÉRIF, votre assistant IA de confiance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 border-t">
        <div className="container max-w-4xl mx-auto text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold">Prêt à commencer ?</h2>
          <p className="text-xl text-muted-foreground">
            Découvrez la puissance de SHÉRIF GPT X1 dès maintenant
          </p>
          <Link href="/chat">
            <Button size="lg" className="gap-2" data-testid="button-cta">
              Démarrer une conversation
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
