import { ThemeProvider } from '../ThemeProvider';
import { ChatInput } from '../ChatInput';

export default function ChatInputExample() {
  return (
    <ThemeProvider defaultTheme="dark">
      <div className="bg-background min-h-[200px]">
        <ChatInput 
          onSend={(message, files) => {
            console.log('Message sent:', message);
            console.log('Files:', files);
          }}
        />
      </div>
    </ThemeProvider>
  );
}
