import { ThemeProvider } from '../ThemeProvider';
import HomePage from '../../pages/HomePage';

export default function HomePageExample() {
  return (
    <ThemeProvider defaultTheme="dark">
      <HomePage />
    </ThemeProvider>
  );
}
