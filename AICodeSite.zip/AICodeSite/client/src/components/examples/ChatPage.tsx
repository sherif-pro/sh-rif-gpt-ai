import { ThemeProvider } from '../ThemeProvider';
import ChatPage from '../../pages/ChatPage';

export default function ChatPageExample() {
  return (
    <ThemeProvider defaultTheme="dark">
      <ChatPage />
    </ThemeProvider>
  );
}
