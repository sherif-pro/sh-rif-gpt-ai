import { ThemeProvider } from '../ThemeProvider';

export default function ThemeProviderExample() {
  return (
    <ThemeProvider defaultTheme="dark">
      <div className="p-8 bg-background text-foreground">
        <h1 className="text-2xl font-bold">Theme Provider Example</h1>
        <p className="text-muted-foreground mt-2">This demonstrates the theme provider with dark mode.</p>
      </div>
    </ThemeProvider>
  );
}
