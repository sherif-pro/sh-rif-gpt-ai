import { ThemeProvider } from '../ThemeProvider';
import { ChatMessage } from '../ChatMessage';

export default function ChatMessageExample() {
  return (
    <ThemeProvider defaultTheme="dark">
      <div className="p-8 bg-background space-y-6">
        <ChatMessage 
          role="user" 
          content="Bonjour SHÉRIF GPT X1, comment ça va ?" 
          timestamp="10:30"
        />
        <ChatMessage 
          role="assistant" 
          content="Bonjour ! Je vais très bien, merci. Je suis SHÉRIF GPT X1, créé par les Développeurs SHÉRIF pour vous assister. Comment puis-je vous aider aujourd'hui ?" 
          timestamp="10:30"
        />
      </div>
    </ThemeProvider>
  );
}
