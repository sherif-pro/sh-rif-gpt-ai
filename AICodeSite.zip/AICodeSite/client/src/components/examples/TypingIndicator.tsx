import { ThemeProvider } from '../ThemeProvider';
import { TypingIndicator } from '../TypingIndicator';

export default function TypingIndicatorExample() {
  return (
    <ThemeProvider defaultTheme="dark">
      <div className="p-8 bg-background">
        <TypingIndicator />
      </div>
    </ThemeProvider>
  );
}
