import { User, Sparkles } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface ChatMessageProps {
  role: "user" | "assistant";
  content: string;
  timestamp?: string;
}

export function ChatMessage({ role, content, timestamp }: ChatMessageProps) {
  const isUser = role === "user";

  return (
    <div className={`flex gap-4 ${isUser ? "flex-row-reverse" : "flex-row"} items-start`}>
      <Avatar className={`h-8 w-8 ${isUser ? "bg-chart-2" : "bg-primary"}`}>
        <AvatarFallback>
          {isUser ? <User className="h-4 w-4 text-white" /> : <Sparkles className="h-4 w-4 text-white" />}
        </AvatarFallback>
      </Avatar>
      
      <div className={`flex flex-col ${isUser ? "items-end" : "items-start"} max-w-[80%]`}>
        <div
          className={`rounded-2xl px-4 py-3 ${
            isUser
              ? "bg-chart-2 text-white"
              : "bg-primary text-primary-foreground"
          }`}
          data-testid={`message-${role}`}
        >
          <p className="text-base leading-relaxed whitespace-pre-wrap">{content}</p>
        </div>
        {timestamp && (
          <span className="text-xs text-muted-foreground mt-1 opacity-70" data-testid="message-timestamp">
            {timestamp}
          </span>
        )}
      </div>
    </div>
  );
}
