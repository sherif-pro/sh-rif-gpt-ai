# Design Guidelines: AI Chat Web Application

## Design Approach
**Selected Approach:** Reference-Based + Design System Hybrid
- **Primary References:** ChatGPT, Claude.ai, Linear (for modern, clean chat interfaces)
- **Supporting System:** Fluent Design principles for productivity focus
- **Key Principles:** Clarity, conversation flow, distraction-free interaction

## Color Palette

**Dark Mode (Primary):**
- Background Base: 222 15% 10%
- Surface Elevated: 222 15% 14%
- Surface Chat: 222 15% 12%
- Border Subtle: 222 10% 20%
- Text Primary: 0 0% 95%
- Text Secondary: 0 0% 70%
- Brand Accent: 262 83% 58% (vibrant purple for AI responses)
- User Message: 217 91% 60% (bright blue)
- Error State: 0 72% 51%

**Light Mode:**
- Background Base: 0 0% 98%
- Surface Elevated: 0 0% 100%
- Surface Chat: 0 0% 96%
- Border Subtle: 0 0% 88%
- Text Primary: 222 15% 10%
- Text Secondary: 222 8% 40%

## Typography

**Font Stack:**
- Primary: 'Inter' via Google Fonts (body, interface)
- Monospace: 'JetBrains Mono' via Google Fonts (code snippets)

**Hierarchy:**
- Hero Headline: text-5xl md:text-6xl font-bold
- Page Title: text-3xl md:text-4xl font-semibold
- Chat Messages: text-base leading-relaxed
- Input Text: text-base
- Timestamps: text-xs text-secondary
- Buttons: text-sm font-medium

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 24
- Message spacing: space-y-6
- Section padding: p-6 md:p-8
- Container gaps: gap-4
- Button padding: px-6 py-3

**Grid Structure:**
- Chat Container: max-w-4xl mx-auto
- Message Width: Full width with inner max-w-3xl
- Sidebar (if added): w-64 fixed left
- Input Area: Full width with max-w-4xl constraint

## Component Library

### Hero Section
- Full-width gradient background (purple to blue subtle)
- Centered content with max-w-4xl
- Headline + subheading + CTA button
- Large hero image: Abstract AI/technology visualization with floating neural network or chat bubbles
- Height: min-h-[60vh]

### Chat Interface
**Message Bubbles:**
- User Messages: Aligned right, blue background (217 91% 60%), rounded-2xl, px-4 py-3
- AI Responses: Aligned left, purple background (262 83% 58%), rounded-2xl, px-4 py-3
- Avatar icons: 8x8 rounded-full (user: blue, AI: purple gradient)
- Timestamp: Bottom-right, text-xs opacity-70
- Max width: 80% of container

**Input Area:**
- Fixed bottom position with backdrop-blur
- Rounded-xl border with shadow-lg
- Auto-expanding textarea (min 3 rows, max 8 rows)
- Send button: Icon-only, circular, brand accent color
- File upload button (optional): Icon, secondary style

### Navigation
- Clean top bar: h-16 with blur backdrop
- Logo left (text or icon + text)
- Navigation items: gap-6, hover:underline
- User profile: right-aligned, avatar + dropdown

### Feature Cards (Landing)
- Grid: grid-cols-1 md:grid-cols-3 gap-8
- Card style: Surface elevated, rounded-xl, p-8
- Icon: Heroicons, 12x12, brand accent
- Heading: text-xl font-semibold
- Description: text-secondary, leading-relaxed

### Loading States
- AI Typing Indicator: Three dots bouncing animation
- Skeleton screens: Pulse animation for message loading
- Spinner: Circular, brand accent color

### Error Handling
- Toast notifications: Bottom-center, slide-up animation
- Inline errors: Red text with icon, below input
- Retry button: Outline style, secondary color

## Images

**Hero Image:**
- Position: Top of landing page, full-width
- Description: Modern, abstract AI visualization - floating neural network nodes, data streams, or holographic chat interface. Color palette: purples, blues, subtle gradients
- Style: High-tech, clean, optimistic
- Dimensions: 1920x800 optimal

**Feature Icons:**
- Use Heroicons CDN
- Suggested icons: ChatBubbleLeftRightIcon, SparklesIcon, BoltIcon, ShieldCheckIcon

## Interactions & Animations

**Message Animations:**
- New message: Slide-up + fade-in (duration-300)
- Send button: Scale on click
- Typing indicator: Gentle pulse

**Micro-interactions:**
- Input focus: Border color transition + subtle glow
- Button hover: Slight scale (scale-105)
- Link hover: Underline transition

**NO Complex Animations:** Avoid parallax, scroll-triggered effects, or heavy JS animations

## Accessibility
- Dark mode as default
- All interactive elements: min 44px touch target
- Keyboard navigation: Focus visible states with ring-2
- ARIA labels for icon buttons
- Color contrast: WCAG AAA compliance

## Page Structure

**Landing Page (5 sections):**
1. Hero with CTA + large background image
2. Feature grid (3 columns)
3. How it works (timeline/steps)
4. Social proof (testimonials 2-col)
5. Final CTA + footer with links

**Chat Interface:**
- Persistent header
- Scrollable message area (flex-1)
- Fixed input at bottom
- Optional sidebar for history

This design creates a modern, professional AI chat experience with clear visual hierarchy and excellent user flow.